# 文件传输应用 - 安装指南

## 📦 打包文件位置

### Android APK
\`\`\`
$(pwd)/build/app/outputs/flutter-apk/app-release.apk
\`\`\`

### macOS APP
\`\`\`
$(pwd)/build/macos/Build/Products/Release/file_trans_local.app
\`\`\`

## 📱 Android 安装

### 方法1: ADB安装
\`\`\`bash
adb install build/app/outputs/flutter-apk/app-release.apk
\`\`\`

### 方法2: 手动安装
1. 复制APK到手机
2. 在手机上点击APK文件
3. 允许"安装未知应用"
4. 点击安装

## 💻 macOS 安装

### 直接运行
\`\`\`bash
# 移除隔离属性（避免安全提示）
xattr -cr build/macos/Build/Products/Release/file_trans_local.app

# 在Finder中打开
open build/macos/Build/Products/Release/

# 双击运行
\`\`\`

### 复制到应用程序文件夹
\`\`\`bash
cp -r build/macos/Build/Products/Release/file_trans_local.app /Applications/
\`\`\`

## ✅ 使用说明

1. **确保两台设备连接到同一WiFi**
2. **Mac发送文件**: 打开应用 → 发送文件 → 选择文件 → 开始发送
3. **Android接收**: 打开应用 → 接收文件 → 扫码或手动输入IP → 接收
4. **APK自动安装**: Android接收APK文件后会提示安装

## 📝 测试步骤

1. 在Mac上启动应用，选择一个APK文件
2. 点击"开始发送"，会显示IP地址和二维码
3. 在Android上打开应用，点击"接收文件"
4. 手动输入Mac显示的IP地址（如: 192.168.1.100:8080）
5. 点击"接收"按钮
6. 等待下载完成
7. 如果是APK，会提示安装

---

生成时间: $(date)
